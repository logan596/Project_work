#!/bin/bash
#exec ("ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null root@192.168.1.22 docker build -t online_exam:1.7 /home/devops/SSHD_docker/ >> /tmp/exam.logs");
#exec ("ssh root@192.168.1.22 docker run -d -P --name 'myonlineexam3' online_exam:2.1 >> /tmp/exam1.logs");
#echo "Your Exam Is Started"
#exec ("ssh root@192.168.1.22 docker ps  | grep myonlineexam | awk -F ':' '{print $3}' | awk -F '->' '{print $1}'");
#exec ("ssh root@192.168.1.22 docker ps  | grep myonlineexam | awk -F : '{print $3}' | awk -F '->' '{print $1}'");

ssh root@192.168.1.22 touch /tmp/exam-started

